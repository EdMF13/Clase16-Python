from setuptools import setup

setup(
    name="mipaquete", 
    version="1.1",
    description="Paquete de funciones y variables matematicas",
    author="Jose Puente",
    author_mail="jpuente2379@gmail.com",
    packages=["paquete"]
)